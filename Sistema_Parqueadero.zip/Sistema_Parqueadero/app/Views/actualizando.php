<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
</head>

<body>
    <div class="container"><br> <br>
        <div class="container-fluid">
            <h1>Actualizar</h1>
            <form action="<?= base_url('factualizar'); ?>" method="POST">
                <div class="form-group">
                    <input type="number" hidden name="id" value="<?= $usuario['id'] ?>">
                    <label for="exampleInputEmail1">placa</label>
                    <input type="text" class="form-control" id="placa" name="placa" value="<?= $usuario['placa'] ?>" required aria-describedby="emailHelp">

                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">vehiculo</label>
                    <input type="text" class="form-control" id="vehiculo" name="vehiculo" value="<?= $usuario['vehiculo'] ?>" required aria-describedby="emailHelp">

                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Nombre del conductore</label>
                    <input type="text" class="form-control" id="nombreconductor" name="nombreconductor" value="<?= $usuario['nombreconductor'] ?>" required aria-describedby="emailHelp">

                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Apellido del conductor</label>
                    <input type="text" class="form-control" id="apellidoconductor" name="apellidoconductor" value="<?= $usuario['apellidoconductor'] ?>" required aria-describedby="emailHelp">


                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Tiempo total</label>
                    <select name="tiempototal" id="tiempototal">
                    <option disabled selected>Selecciona una opción</option>
                    <option value="<?= $usuario['tiempototal'] ?>">1-2 horas</option>
                    <option value="<?= $usuario['tiempototal'] ?>">3-4 horas</option>
                    <option value="<?= $usuario['tiempototal'] ?>">5-6 horas</option>
                    <option value="<?= $usuario['tiempototal'] ?>">7-8 horas</option>
                    <option value="<?= $usuario['tiempototal'] ?>">Más</option>
                 </select>

                </div>
                <br>

                <button type="submit" class="btn btn-primary">Actualizar</button>
            </form>
        </div>
    </div>

</body>

</html>