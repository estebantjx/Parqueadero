<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Vehiculo;
class C_persona extends Controller{

    public function index()
    {
        $car = new Vehiculo();
        $datos['carro']=$car->findAll();
        return view('welcome_message',$datos);
    }

    public function agregar()
    {

        
        return view('agregar');
    }
    public function insertar()
    {
       
        $car = new Vehiculo();

        $data=[
            'placa' => $_POST['placa'],
            'vehiculo' => $_POST['vehiculo'],
            'nombreconductor' => $_POST['nombreconductor'],
            'apellidoconductor' => $_POST['apellidoconductor'],
            'tiempototal' => $_POST['tiempototal']
        ];

        $car->insert($data);
        return redirect()->to(base_url());
       
        

        
    }
    public function eliminar($id=null)
    {
        
      

       $car = new Vehiculo();
        $car->delete($id);

        
        return redirect()->to(base_url());
    }
    public function editar($id = null)
    {

        $car = new Vehiculo();
        $registro['carro']= $car->find($id);

      return view('actualizando',$registro);
     


       // return redirect()->to(base_url());
    }
    public function factualizar()
    {

        $car = new Vehiculo();
        $id= $_POST['id'];

        $data = [

            'placa' => $_POST['placa'],
            'vehiculo' => $_POST['vehiculo'],
            'nombreconductor' => $_POST['nombreconductor'],
            'apellidoconductor' => $_POST['apellidoconductor'],
            'tiempototal' => $_POST['tiempototal']  
        ];
        $car->update($id,$data);

        



       return redirect()->to(base_url());
    }





}